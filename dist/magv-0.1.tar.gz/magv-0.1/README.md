## Mangrove - A PostgreSQL Extension Manager

This is a PostgreSQL extension manager, a command-line tool to download and install PostgreSQL extensions. You can download extension supported by [PGXN](https://pgxn.org/) or [Mangrove Index](https://atomgit.com/haorongxu/magv-index).